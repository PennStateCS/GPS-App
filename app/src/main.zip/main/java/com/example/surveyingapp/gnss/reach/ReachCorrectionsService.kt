package com.example.surveyingapp.gnss.reach

import org.json.JSONObject

data class ReachCorrectionsInfo(
    val isReceiving: Boolean,
    val channel: String?,           // NTRIP, LoRa, Serial, etc.
    val satellitesInView: Int?,     // Satellites in correction stream
    val ageSeconds: Double?,        // Age of corrections
    val baselineKm: Double?,        // Baseline distance to base station
    val baseLatDeg: Double?,        // Base station latitude
    val baseLonDeg: Double?,        // Base station longitude
    val baseAltM: Double?           // Base station altitude
)

/**
 * Fetches RTK correction status from RS2+ device.
 * Tries /corrections, /rtk/status, and /position/correction endpoints.
 */
class ReachCorrectionsService(private val client: ReachHttpClient) {
    suspend fun read(): ReachCorrectionsInfo? {
        val text = runCatching { client.get("/corrections") }
            .getOrElse {
                runCatching { client.get("/rtk/status") }
                    .getOrElse { client.get("/position/correction") }
            }

        val j = JSONObject(text)

        // Try different JSON structures (RS2+ API variations)
        val corrections = j.optJSONObject("corrections") ?: j
        val rtk = j.optJSONObject("rtk") ?: corrections.optJSONObject("rtk")
        val base = j.optJSONObject("base") ?: corrections.optJSONObject("base")
            ?: rtk?.optJSONObject("base")

        return ReachCorrectionsInfo(
            isReceiving = corrections.optBoolean("receiving", false)
                || corrections.optString("status")?.contains("receiving", ignoreCase = true) == true,
            channel = corrections.optString("channel")?.takeIf { it.isNotBlank() }
                ?: corrections.optString("source")?.takeIf { it.isNotBlank() },
            satellitesInView = corrections.optInt("satellites", -1).takeIf { it >= 0 }
                ?: corrections.optInt("sats_in_view", -1).takeIf { it >= 0 },
            ageSeconds = corrections.optDouble("age", Double.NaN).takeIf { it.isFinite() }
                ?: corrections.optDouble("age_seconds", Double.NaN).takeIf { it.isFinite() },
            baselineKm = corrections.optDouble("baseline", Double.NaN).takeIf { it.isFinite() && it > 0 }
                ?: (rtk?.optDouble("baseline_m", Double.NaN)?.div(1000.0))?.takeIf { it.isFinite() && it > 0 },
            baseLatDeg = base?.optDouble("latitude", Double.NaN)?.takeIf { it.isFinite() }
                ?: base?.optDouble("lat", Double.NaN)?.takeIf { it.isFinite() },
            baseLonDeg = base?.optDouble("longitude", Double.NaN)?.takeIf { it.isFinite() }
                ?: base?.optDouble("lon", Double.NaN)?.takeIf { it.isFinite() },
            baseAltM = base?.optDouble("altitude", Double.NaN)?.takeIf { it.isFinite() }
                ?: base?.optDouble("alt", Double.NaN)?.takeIf { it.isFinite() }
        )
    }
}

