package com.example.surveyingapp.data.repository.mapper

import com.example.surveyingapp.data.local.db.DbConstants
import com.example.surveyingapp.data.local.entity.CoordinateEntity
import com.example.surveyingapp.domain.model.CorrectionSource
import com.example.surveyingapp.domain.model.Coordinate
import com.example.surveyingapp.gnss.model.Fix
import com.example.surveyingapp.gnss.model.Provider
import com.example.surveyingapp.gnss.model.RtkStatus
import java.util.Locale
import java.util.UUID

// ---------- Helpers: enum <-> domain string ----------

private fun providerEnumToDomainString(p: Provider): String = when (p) {
    Provider.INTERNAL     -> DbConstants.PROVIDER_FUSED   // "fused"
    Provider.RS2_EXTERNAL -> DbConstants.PROVIDER_RS2_TCP // "rs2-tcp" (or could be a new constant)
    Provider.RS2_BT       -> DbConstants.PROVIDER_RS2_BT  // "rs2-bt"
    Provider.RS2_TCP      -> DbConstants.PROVIDER_RS2_TCP // "rs2-tcp"
    Provider.OTHER        -> "other"
    Provider.MODEL        -> "model"
}

private fun providerDomainStringToEnum(s: String?): Provider = when (s?.lowercase(Locale.US)) {
    DbConstants.PROVIDER_FUSED, "internal", "fused", "internal_gps" -> Provider.INTERNAL
    DbConstants.PROVIDER_RS2_BT, "rs2-bt", "rs2_bt"                -> Provider.RS2_BT
    DbConstants.PROVIDER_RS2_TCP, "rs2-tcp", "rs2_tcp"             -> Provider.RS2_TCP
    "rs2-external", "rs2_external"                                  -> Provider.RS2_EXTERNAL
    "model"                                                         -> Provider.MODEL
    else                                                            -> Provider.OTHER
}

private fun rtkEnumToDomainString(rtk: RtkStatus?): String? = rtk?.name
private fun rtkDomainStringToEnum(s: String?): RtkStatus? =
    s?.let { runCatching { RtkStatus.valueOf(it.uppercase(Locale.US)) }.getOrNull() }

private fun corrEnumToDomainString(c: CorrectionSource?): String? = c?.name
private fun corrDomainStringToEnum(s: String?): CorrectionSource? =
    s?.let { runCatching { CorrectionSource.valueOf(it.uppercase(Locale.US)) }.getOrNull() }

// ---------- Builders / Mappers ----------

/**
 * Build a CoordinateEntity from a captured point + the latest Fix metadata.
 * Use when user creates a brand-new point from a live fix.
 */
fun toEntityFromFix(
    id: String = UUID.randomUUID().toString(),
    name: String,
    icon: String,
    color: Int,
    note: String?,
    fix: Fix
): CoordinateEntity = CoordinateEntity(
    id = id,
    name = name,
    latitude = fix.latDeg,
    longitude = fix.lonDeg,
    altitude = fix.altEllipsoidalM ?: 0.0,     // ellipsoidal height; 0.0 if receiver didn't provide it
    timestamp = fix.timeUtc.toEpochMilli(),
    icon = icon,
    color = color,

    provider = fix.provider,
    rtkStatus = fix.rtkStatus,
    satsUsed = fix.satsUsed,
    satsVisible = fix.satsVisible,
    hdop = fix.hDop,
    vDop = fix.vDop,
    pDop = fix.pDop,
    horizontalAccuracyM = fix.hAccM,
    verticalAccuracyM = fix.vAccM,
    correctionSource = null,                    // CorrectionSource enum not carried in Fix
    correctionAgeS = fix.diffAgeS,
    correctionStationId = fix.correctionStationId,
    speedMps = fix.speedMps,
    courseDeg = fix.courseDeg,
    timestampSource = fix.timestampSource.name,
    multipathIndex = fix.multipathIndex,

    altitudeMsl = fix.altMslM,
    geoidSeparationM = fix.geoidSeparationM,
    crsEpsg = 4326,

    easting = null,
    northing = null,
    utmZone = null,

    note = note,
    averagedSamples = null,
    averageDurationMs = null,
    stdLatM = fix.stdDevNorthM,
    stdLonM = fix.stdDevEastM,
    stdAltM = fix.stdDevUpM,

    sourceDevice = null,
    appVersion = null
)

/**
 * TEMP compatibility wrapper, in case other call sites still use the old name.
 * Prefer toEntityFromFix(...) to avoid confusion with the Coordinate extension.
 */
@Deprecated("Use toEntityFromFix(...)")
fun toEntity(
    id: String = UUID.randomUUID().toString(),
    name: String,
    icon: String,
    color: Int,
    note: String?,
    fix: Fix
): CoordinateEntity = toEntityFromFix(id, name, icon, color, note, fix)

/** Map a DB row back to the domain Coordinate. */
fun CoordinateEntity.toDomain(): Coordinate = Coordinate(
    id = id,
    name = name,
    latitude = latitude,
    longitude = longitude,
    altitude = altitude,
    timestamp = timestamp,
    icon = icon,
    color = color,

    provider = providerEnumToDomainString(provider),
    rtkStatus = rtkEnumToDomainString(rtkStatus),
    satsUsed = satsUsed,
    satsVisible = satsVisible,
    hdop = hdop,
    vDop = vDop,
    pDop = pDop,
    horizontalAccuracyM = horizontalAccuracyM,
    verticalAccuracyM = verticalAccuracyM,
    correctionSource = corrEnumToDomainString(correctionSource),
    correctionAgeS = correctionAgeS,
    correctionStationId = correctionStationId,
    speedMps = speedMps,
    courseDeg = courseDeg,
    timestampSource = timestampSource,
    multipathIndex = multipathIndex,

    altitudeMsl = altitudeMsl,
    geoidSeparationM = geoidSeparationM,
    crsEpsg = crsEpsg,

    easting = easting,
    northing = northing,
    utmZone = utmZone,

    note = note,
    captureMethod = captureMethod,
    averagedSamples = averagedSamples,
    averageDurationMs = averageDurationMs,
    stdLatM = stdLatM,
    stdLonM = stdLonM,
    stdAltM = stdAltM,

    sourceDevice = sourceDevice,
    appVersion = appVersion
)

/** Map a domain Coordinate back to a CoordinateEntity for DB writes. */
fun Coordinate.toEntity(): CoordinateEntity =
    CoordinateEntity(
        id = id,
        name = name,
        latitude = latitude,
        longitude = longitude,
        altitude = altitude,
        timestamp = timestamp,
        icon = icon,
        color = color,

        provider = providerDomainStringToEnum(provider),
        rtkStatus = rtkDomainStringToEnum(rtkStatus),
        satsUsed = satsUsed,
        satsVisible = satsVisible,
        hdop = hdop,
        vDop = vDop,
        pDop = pDop,
        horizontalAccuracyM = horizontalAccuracyM,
        verticalAccuracyM = verticalAccuracyM,
        correctionSource = corrDomainStringToEnum(correctionSource),
        correctionAgeS = correctionAgeS,
        correctionStationId = correctionStationId,
        speedMps = speedMps,
        courseDeg = courseDeg,
        timestampSource = timestampSource,
        multipathIndex = multipathIndex,

        altitudeMsl = altitudeMsl,
        geoidSeparationM = geoidSeparationM,
        crsEpsg = crsEpsg,

        easting = easting,
        northing = northing,
        utmZone = utmZone,

        note = note,
        captureMethod = captureMethod,
        averagedSamples = averagedSamples,
        averageDurationMs = averageDurationMs,
        stdLatM = stdLatM,
        stdLonM = stdLonM,
        stdAltM = stdAltM,

        sourceDevice = sourceDevice,
        appVersion = appVersion
    )
