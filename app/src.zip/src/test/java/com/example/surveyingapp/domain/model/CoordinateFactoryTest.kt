package com.example.surveyingapp.domain.model

import com.example.surveyingapp.gnss.capture.CaptureResult
import com.example.surveyingapp.gnss.model.Provider
import com.example.surveyingapp.gnss.model.RtkStatus
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class CoordinateFactoryTest {

    private fun captureResult(
        latDeg: Double = 40.7128,
        lonDeg: Double = -74.0060,
        altEllipsoidalM: Double = 10.5,
        rtkStatus: RtkStatus? = RtkStatus.FIX,
        satsUsed: Int? = 14,
        satsVisible: Int? = 22,
        hdop: Double? = 0.8,
        vDop: Double? = 1.2,
        pDop: Double? = 1.5,
        hAccM: Double? = 0.012,
        vAccM: Double? = 0.018,
        diffAgeS: Double? = 2.3,
        correctionStationId: String? = "ABCD",
        samples: Int = 180,
        startedAt: Instant = Instant.ofEpochMilli(1_700_000_000_000L),
        endedAt: Instant = Instant.ofEpochMilli(1_700_000_060_000L)
    ) = CaptureResult(
        startedAt = startedAt,
        endedAt = endedAt,
        samples = samples,
        latDeg = latDeg,
        lonDeg = lonDeg,
        altEllipsoidalM = altEllipsoidalM,
        ecefStd = Triple(0.001, 0.001, 0.002),
        rtkStatus = rtkStatus,
        satsUsed = satsUsed,
        satsVisible = satsVisible,
        hdop = hdop,
        vDop = vDop,
        pDop = pDop,
        hAccM = hAccM,
        vAccM = vAccM,
        diffAgeS = diffAgeS,
        correctionStationId = correctionStationId
    )

    @Test
    fun `fromCaptureResult maps position fields`() {
        val result = captureResult()
        val coord = CoordinateFactory.fromCaptureResult(
            id = "test-id", name = "P1", note = null,
            color = 0xFF3F51B5.toInt(), iconId = "pin",
            provider = Provider.RS2_EXTERNAL, result = result
        )

        assertEquals(result.latDeg, coord.latitude, 1e-10)
        assertEquals(result.lonDeg, coord.longitude, 1e-10)
        assertEquals(result.altEllipsoidalM, coord.altitude, 1e-10)
        assertEquals(result.endedAt.toEpochMilli(), coord.timestamp)
    }

    @Test
    fun `fromCaptureResult maps all quality fields`() {
        val result = captureResult()
        val coord = CoordinateFactory.fromCaptureResult(
            id = "q", name = "Q", note = "survey note",
            color = 0, iconId = "pin",
            provider = Provider.RS2_EXTERNAL, result = result
        )

        assertEquals(RtkStatus.FIX.name, coord.rtkStatus)
        assertEquals(14, coord.satsUsed)
        assertEquals(22, coord.satsVisible)
        assertEquals(0.8, coord.hdop!!, 1e-10)
        assertEquals(1.2, coord.vDop!!, 1e-10)
        assertEquals(1.5, coord.pDop!!, 1e-10)
        assertEquals(0.012, coord.horizontalAccuracyM!!, 1e-10)
        assertEquals(0.018, coord.verticalAccuracyM!!, 1e-10)
        assertEquals(2.3, coord.correctionAgeS!!, 1e-10)
        assertEquals("ABCD", coord.correctionStationId)
        assertEquals(180, coord.averagedSamples)
        assertEquals(60_000L, coord.averageDurationMs)
        assertEquals("survey note", coord.note)
    }

    @Test
    fun `fromCaptureResult populates UTM fields for valid coordinates`() {
        val result = captureResult(latDeg = 40.7128, lonDeg = -74.0060)
        val coord = CoordinateFactory.fromCaptureResult(
            id = "utm", name = "UTM", note = null,
            color = 0, iconId = "pin",
            provider = Provider.RS2_EXTERNAL, result = result
        )

        assertNotNull("easting should not be null", coord.easting)
        assertNotNull("northing should not be null", coord.northing)
        assertEquals("18N", coord.utmZone)
        assertEquals(4326, coord.crsEpsg)
    }

    @Test
    fun `fromCaptureResult stores provider name`() {
        val coord = CoordinateFactory.fromCaptureResult(
            id = "p", name = "P", note = null, color = 0, iconId = "pin",
            provider = Provider.INTERNAL, result = captureResult()
        )
        assertEquals(Provider.INTERNAL.name, coord.provider)
    }

    @Test
    fun `fromCaptureResult handles nullable quality fields gracefully`() {
        val sparse = captureResult(
            rtkStatus = null, satsUsed = null, satsVisible = null,
            hdop = null, vDop = null, pDop = null,
            hAccM = null, vAccM = null, diffAgeS = null, correctionStationId = null
        )
        val coord = CoordinateFactory.fromCaptureResult(
            id = "s", name = "S", note = null, color = 0, iconId = "pin",
            provider = Provider.OTHER, result = sparse
        )

        assertNull(coord.rtkStatus)
        assertNull(coord.satsUsed)
        assertNull(coord.satsVisible)
        assertNull(coord.hdop)
        assertNull(coord.vDop)
        assertNull(coord.pDop)
        assertNull(coord.horizontalAccuracyM)
        assertNull(coord.verticalAccuracyM)
        assertNull(coord.correctionAgeS)
        assertNull(coord.correctionStationId)
    }
}
